"""
SEBAL-GEE v4 — M1: Preprocessing
=================================
Landsat 8/9 C2L2 tasvirlarini tozalash va tayyorlash.

Vazifalar:
  1. ImageCollection qurish (L8, L9 yoki ikkalasi)
  2. Cloud cover bo'yicha filtr
  3. QA_PIXEL bitmask — bulut, soya, qor, suv olib tashlash
  4. Scale factors qo'llash (SR → 0-1, ST → Kelvin)
  5. DEM va slope qo'shish
  6. ERA5 vaqtga moslashtirish

Input:  ROI, date_range, satellite config
Output: Toza ee.ImageCollection (har bir image tayyor)
"""

import ee
from . import config as cfg


# ==============================================================
# QA MASK — bulut, soya, qor olib tashlash
# ==============================================================

def apply_qa_mask(image):
    """
    QA_PIXEL band dan sifat maskasi yaratish.

    Olib tashlanadi:
      - Fill pixels (bit 0)
      - Dilated cloud (bit 1)
      - Cirrus (bit 2)
      - Cloud (bit 3)
      - Cloud shadow (bit 4)
      - Snow (bit 5)

    Suv (bit 7) — olib tashlanMAYDI, chunki SEBAL suv
    piksellarni G₀ = 0.5×Q* bilan ishlata oladi.
    Lekin alohida suv maskasi saqlanadi.
    """
    qa = image.select(cfg.BAND_NAMES['qa'])

    # Yomon piksellar maskasi — bularni OLIB TASHLAYMIZ
    bad_mask = (
        qa.bitwiseAnd(cfg.QA_BITMASK['fill'])
        .Or(qa.bitwiseAnd(cfg.QA_BITMASK['dilated_cloud']))
        .Or(qa.bitwiseAnd(cfg.QA_BITMASK['cirrus']))
        .Or(qa.bitwiseAnd(cfg.QA_BITMASK['cloud']))
        .Or(qa.bitwiseAnd(cfg.QA_BITMASK['cloud_shadow']))
        .Or(qa.bitwiseAnd(cfg.QA_BITMASK['snow']))
    )

    # Toza piksellar = bad_mask EMAS
    clear_mask = bad_mask.Not()

    # Suv maskasi — alohida band sifatida saqlaymiz
    water_mask = qa.bitwiseAnd(cfg.QA_BITMASK['water']).gt(0)

    return (image
            .updateMask(clear_mask)
            .addBands(water_mask.rename('WATER_MASK')))


# ==============================================================
# SCALE FACTORS — raw DN → physical units
# ==============================================================

def apply_scale_factors(image):
    """
    C2L2 scale factors qo'llash.

    SR bands (B2-B7): DN × 0.0000275 - 0.2 → reflectance (0–1)
    ST band (B10):    DN × 0.00341802 + 149.0 → Kelvin

    SR qiymatlari 0–1 oralig'iga clamp qilinadi.
    """
    sr_bands = [
        cfg.BAND_NAMES['blue'],
        cfg.BAND_NAMES['green'],
        cfg.BAND_NAMES['red'],
        cfg.BAND_NAMES['nir'],
        cfg.BAND_NAMES['swir1'],
        cfg.BAND_NAMES['swir2'],
    ]

    st_band = cfg.BAND_NAMES['thermal']

    # Surface Reflectance — scale va clamp
    sr_scaled = (image.select(sr_bands)
                 .multiply(cfg.SCALE_FACTORS['sr_mult'])
                 .add(cfg.SCALE_FACTORS['sr_add'])
                 .clamp(0.0, 1.0))

    # Surface Temperature — Kelvin ga
    st_scaled = (image.select(st_band)
                 .multiply(cfg.SCALE_FACTORS['st_mult'])
                 .add(cfg.SCALE_FACTORS['st_add'])
                 .rename('LST'))

    # Asl bandlarni yangilangan qiymatlarga almashtirish
    # QA va boshqa bandlar saqlanadi
    return (image
            .addBands(sr_scaled, overwrite=True)
            .addBands(st_scaled))


# ==============================================================
# DEM & SLOPE — SRTM 30m
# ==============================================================

def add_terrain(image, roi):
    """
    Har bir tasvirga DEM va slope qo'shish.

    DEM:   τsw hisoblash uchun (Allen 2007)
    Slope: Anchor pixel filtrida (slope < 5°)

    CRS tekshiruvi: DEM Landsat bilan bir xil proeksiyada
    reprojekt qilinadi — oldingi z₀m bug'ining oldini olish!
    """
    dem = (ee.Image(cfg.DEM['collection'])
           .select(cfg.DEM['band'])
           .rename('DEM'))

    # Landsat tasvirning CRS ini olish
    landsat_crs = image.select(cfg.BAND_NAMES['red']).projection()

    # DEM ni Landsat CRS ga reproject qilish
    # BU MUHIM — oldingi z₀m bug' CRS mismatch sababli edi!
    dem_aligned = dem.reproject(crs=landsat_crs, scale=30)

    # Slope hisoblash (degrees)
    slope = ee.Terrain.slope(dem_aligned).rename('SLOPE')

    return image.addBands(dem_aligned).addBands(slope)


# ==============================================================
# ERA5 METEOROLOGICAL DATA
# ==============================================================

def get_era5_for_image(image, roi):
    """
    Landsat tasvir sanasiga mos ERA5 ma'lumotlarini olish.

    ERA5 hourly — Landsat overpass vaqtiga eng yaqin soatni tanlaymiz.

    MUHIM: system:time_start ALLAQACHON haqiqiy UTC vaqtni o'z ichiga
    oladi. Idaho uchun ~17:30 UTC, O'zbekiston uchun ~05:30 UTC.
    Hardcoded soat ISHLATMAYMIZ — image ning o'z vaqtidan ±1 soat.

    Returns: ee.Image with ERA5 bands added
    """
    # Landsat tasvir sanasi va vaqtini olish
    # Bu ALLAQACHON to'g'ri UTC vaqt — 2024-07-07T17:30:00Z
    date = ee.Date(image.get('system:time_start'))

    # ±1 soat oyna — overpass atrofida
    era5_start = date.advance(-1, 'hour')
    era5_end = date.advance(1, 'hour')

    # ERA5 collection filtr
    era5 = (ee.ImageCollection(cfg.ERA5['collection'])
            .filterDate(era5_start, era5_end)
            .filterBounds(roi)
            .mean())  # 2 soatlik oynada o'rtacha

    # Wind speed hisoblash: u va v komponentlardan
    u_wind = era5.select(cfg.ERA5['bands']['u_wind'])
    v_wind = era5.select(cfg.ERA5['bands']['v_wind'])
    wind_speed = (u_wind.pow(2).add(v_wind.pow(2))
                  .sqrt()
                  .rename('WIND_SPEED_10M'))

    # Air temperature (K)
    air_temp = era5.select(cfg.ERA5['bands']['air_temp']).rename('AIR_TEMP')

    # Surface pressure (Pa)
    pressure = era5.select(cfg.ERA5['bands']['pressure']).rename('PRESSURE')

    # Incoming solar radiation (W/m²)
    # ERA5 ssrd — accumulated, soatlik farqni olish kerak
    ssrd = era5.select(cfg.ERA5['bands']['ssrd']).rename('SSRD')

    # Incoming longwave radiation (W/m²)
    strd = era5.select(cfg.ERA5['bands']['strd']).rename('STRD')
    
    # Dewpoint temperature (K) — et_decomposition uchun
    dewpoint = era5.select(cfg.ERA5['bands']['dewpoint']).rename('DEWPOINT')

    # Bitta image ga birlashtirish
    era5_combined = (wind_speed
                        .addBands(air_temp)
                        .addBands(pressure)
                        .addBands(ssrd)
                        .addBands(strd)
                        .addBands(dewpoint))

    return image.addBands(era5_combined)


# ==============================================================
# AIR DENSITY — barometrik formula
# ==============================================================

def add_air_density(image):
    """
    Havo zichligini hisoblash.

    ρₐ = P / (R_specific × T)

    P — ERA5 surface pressure (Pa)
    T — ERA5 air temperature (K)
    R_specific = 287.058 J/(kg·K)
    """
    R_SPECIFIC = 287.058  # J/(kg·K)

    pressure = image.select('PRESSURE')
    air_temp = image.select('AIR_TEMP')

    rho_air = pressure.divide(air_temp.multiply(R_SPECIFIC)).rename('RHO_AIR')

    return image.addBands(rho_air)


# ==============================================================
# MAIN: Build clean ImageCollection
# ==============================================================

def build_collection(roi, date_start, date_end, satellite='BOTH',
                     cloud_max=None, mosaic_same_date=True,
                     wrs_path=None, wrs_row=None):
    """
    Toza Landsat ImageCollection qurish.

    Parameters
    ----------
    roi : ee.Geometry
        Qiziqish hududi
    date_start : str
        Boshlanish sanasi ('YYYY-MM-DD')
    date_end : str
        Tugash sanasi ('YYYY-MM-DD')
    satellite : str
        'L8', 'L9', yoki 'BOTH'
    cloud_max : int, optional
        Maximum cloud cover % (default: config dan)

    Returns
    -------
    ee.ImageCollection
        Har bir image tarkibida:
        - SR bands (0–1 scaled)
        - LST (Kelvin)
        - WATER_MASK
        - DEM, SLOPE
        - ERA5 bands (wind, temp, pressure, radiation)
        - RHO_AIR
    """
    if cloud_max is None:
        cloud_max = cfg.PIPELINE['cloud_max_percent']

    # Qaysi satellite(lar)?
    if satellite == 'BOTH':
        collections = ['L8', 'L9']
    else:
        collections = [satellite]

    # ImageCollection(lar) qurish va birlashtirish
    merged = None

    for sat_key in collections:
        collection_id = cfg.LANDSAT_COLLECTIONS[sat_key]

        col = (ee.ImageCollection(collection_id)
               .filterBounds(roi)
               .filterDate(date_start, date_end)
               .filter(ee.Filter.lt('CLOUD_COVER', cloud_max)))

        if merged is None:
            merged = col
        else:
            merged = merged.merge(col)

    # Har bir image ga preprocessing qo'llash
    def preprocess_image(image):
        """Bitta tasvirni to'liq tayyorlash pipeline."""
        processed = apply_qa_mask(image)
        processed = apply_scale_factors(processed)
        processed = add_terrain(processed, roi)
        processed = get_era5_for_image(processed, roi)
        processed = add_air_density(processed)
        return processed
    
    # WRS filtr — preprocessing dan OLDIN (tez va to'g'ri)
    if wrs_path is not None:
        merged = merged.filter(ee.Filter.eq('WRS_PATH', wrs_path))
    if wrs_row is not None:
        merged = merged.filter(ee.Filter.eq('WRS_ROW', wrs_row))

    # Bir sanada L8+L9 bo'lsa — eng yaxshisini olish
    if wrs_path is not None:
        distinct_dates = (merged
            .aggregate_array('system:time_start')
            .map(lambda t: ee.Date(t).format('YYYY-MM-dd'))
            .distinct())

        def best_per_date(date_str):
            date = ee.Date(date_str)
            daily = merged.filterDate(date, date.advance(1, 'day'))
            return daily.sort('CLOUD_COVER').first()

        merged = ee.ImageCollection(distinct_dates.map(best_per_date))

    clean_collection = merged.map(preprocess_image)
    
  
    if mosaic_same_date:
        # Bir xil sanadagi tasvirlarni mosaic (ROI mode uchun)
        distinct_dates = (clean_collection
                          .aggregate_array('system:time_start')
                          .map(lambda t: ee.Date(t).format('YYYY-MM-dd'))
                          .distinct())

        def mosaic_by_date(date_str):
            date = ee.Date(date_str)
            daily = clean_collection.filterDate(date, date.advance(1, 'day'))
            mosaic = daily.mosaic()
            return mosaic.set('system:time_start', date.millis())

        clean_collection = ee.ImageCollection(
            distinct_dates.map(mosaic_by_date))

    return clean_collection

# ==============================================================
# UTILITY: Collection info
# ==============================================================

def collection_info(collection):
    """
    Collection haqida qisqacha ma'lumot.

    Returns: dict with count, dates, satellites
    """
    count = collection.size().getInfo()
    dates = (collection.aggregate_array('system:time_start')
             .map(lambda t: ee.Date(t).format('YYYY-MM-dd'))
             .getInfo())

    return {
        'image_count': count,
        'dates': dates,
    }