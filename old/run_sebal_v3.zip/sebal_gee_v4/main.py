"""
SEBAL-GEE v4 — Main Pipeline (Production)
===========================================
Ishlatish: run_sebal.py dan chaqiriladi.

Xususiyatlar:
  - Oylik: har produkt alohida TIF (True/False)
  - Kunlik: multi-band (1 fayl per sahna)
  - Tile-based: WRS path/row bo'yicha alohida ishlash
  - ROI: gaul, rectangle, shapefile, point
"""

import ee

from . import config as cfg
from . import preprocessing
from . import surface_props
from . import radiation
from . import energy_balance
from . import daily_et


# ==============================================================
# DAILY BAND SETS
# ==============================================================

DAILY_BANDS_MAQOLA = [
    'ET_24', 'LAMBDA_E', 'H', 'RN', 'G0', 'EVAP_FRAC', 'NDVI', 'LST','LAI',
]

DAILY_BANDS_PYSEBAL = [
    'ET_24', 'ETREF_24', 'ETPOT_24', 'ET_DEFICIT',
    'KC', 'KC_MAX', 'ADV_FACTOR',
    'TACT_24', 'EACT_24', 'TPOT_24', 'T_DEFICIT',
    'BENEFICIAL_FRACTION', 'MOISTURE_STRESS',
    'TOP_SOIL_MOISTURE', 'ROOT_ZONE_MOISTURE', 'SM_WETNESS',
    'FPAR', 'APAR', 'LUE',
    'BIOMASS_PROD', 'WATER_PRODUCTIVITY', 'BIOMASS_DEFICIT',
    'IRRIGATION_CLASS', 'IRRIGATION_DEPTH',
    'NDVI', 'LST',
]


# ==============================================================
# WRS TILES — path/row aniqlash
# ==============================================================

def detect_wrs_tiles(roi, date_start, date_end, satellite='BOTH', cloud_max=20):
    """
    ROI ichidagi WRS path/row larni aniqlash.
    Qaysi tilelar mavjud ekanini ko'rsatadi.
    """
    collections = []
    if satellite in ('BOTH', 'L8'):
        collections.append('LANDSAT/LC08/C02/T1_L2')
    if satellite in ('BOTH', 'L9'):
        collections.append('LANDSAT/LC09/C02/T1_L2')

    tiles = set()
    for col_id in collections:
        col = (ee.ImageCollection(col_id)
               .filterBounds(roi)
               .filterDate(date_start, date_end)
               .filter(ee.Filter.lt('CLOUD_COVER', cloud_max)))

        props = col.aggregate_array('WRS_PATH').zip(
            col.aggregate_array('WRS_ROW')).distinct().getInfo()

        for p, r in props:
            tiles.add((p, r))

    return sorted(tiles)


def get_tile_geometry(path, row):
    """WRS path/row geometriyasini Landsat C2 dan olish."""
    tile = (ee.ImageCollection('LANDSAT/LC08/C02/T1_L2')
            .filter(ee.Filter.eq('WRS_PATH', path))
            .filter(ee.Filter.eq('WRS_ROW', row))
            .first()
            .geometry())
    return tile

# ==============================================================
# BITTA TILE NI ISHLASH
# ==============================================================

def process_tile(roi, date_start, date_end, mode, satellite, cloud_max,
                 tile_label=''):
    """
    Bitta ROI/tile uchun SEBAL pipeline.
    Returns: list of processed scene images
    """
    prefix = f"  [{tile_label}]" if tile_label else "  "

    # Preprocessing
    collection = preprocessing.build_collection(
        roi=roi, date_start=date_start, date_end=date_end,
        satellite=satellite, cloud_max=cloud_max)
    
    if tile_label:
            path_num = int(tile_label.split('_')[0].replace('P', ''))
            row_num = int(tile_label.split('_')[1].replace('R', ''))
    else:
        path_num = None
        row_num = None

        collection = preprocessing.build_collection(
            roi=roi, date_start=date_start, date_end=date_end,
            satellite=satellite, cloud_max=cloud_max,
            mosaic_same_date=not bool(tile_label),
            wrs_path=path_num, wrs_row=row_num)
        print(f"{prefix} Filtrlangan: Path={path_num} Row={row_num} → {info['image_count']} tasvir")

    info = preprocessing.collection_info(collection)
    print(f"{prefix} Tasvirlar: {info['image_count']} | {info['dates']}")

    if info['image_count'] == 0:
        print(f"{prefix} ⚠️ Tasvir yo'q, o'tkazildi")
        return [], info

    # Surface props + radiation
    collection = collection.map(surface_props.compute_all)
    collection = collection.map(radiation.compute_all)

    # Energy balance (har sahna alohida)
    image_list = collection.toList(collection.size())
    n = info['image_count']

    scene_images = []
    for i in range(n):
        print(f"{prefix} Sahna {i+1}/{n}...")
        img = ee.Image(image_list.get(i))
        img = energy_balance.compute_all(img, roi)
        img = daily_et.compute_daily_et(img, roi)

        if mode == 'pysebal':
            from . import et_decomposition, soil_moisture, biomass, irrigation
            img = et_decomposition.compute_all(img)
            img = soil_moisture.compute_all(img)
            img = biomass.compute_all(img)
            img = irrigation.compute_all(img)

        scene_images.append(img)

    return scene_images, info


# ==============================================================
# EXPORT — kunlik
# ==============================================================

def _export_daily(scene_images, info, roi, mode, folder, scale, crs,
                 tile_label=''):
    """Kunlik rasterlar — multi-band, har sahna alohida fayl."""
    bands = DAILY_BANDS_PYSEBAL if mode == 'pysebal' else DAILY_BANDS_MAQOLA
    tasks = []

    for i, img in enumerate(scene_images):

        # GEE cache — tezlashtirish
        try:
            st = (img.select(['ET_24', 'NDVI'])
                  .reduceRegion(ee.Reducer.minMax(), roi, 1000,
                               maxPixels=1e8, bestEffort=True).getInfo())
            et_min = st.get('ET_24_min', 0)
            et_max = st.get('ET_24_max', 0)
            ndvi_max = st.get('NDVI_max', 0)
            print(f"  📊 ET: {et_min:.1f}-{et_max:.1f} mm/day | NDVI max: {ndvi_max:.2f}")
        except:
            pass
        
        d = (ee.Date(img.get('system:time_start'))
             .format('YYYY-MM-dd').getInfo())

        name = f'SEBAL_day_{d}'
        if tile_label:
            name = f'SEBAL_day_{d}_{tile_label}'

        task = ee.batch.Export.image.toDrive(
            image=img.select(bands).toFloat(),
            description=name, folder=folder, fileNamePrefix=name,
            region=roi, scale=scale, crs=crs,
            maxPixels=1e13, fileFormat='GeoTIFF')
        
        task.start()
        tasks.append(task.id)
        print(f"  ✅ {name} ({len(bands)} band)")

    return tasks


# ==============================================================
# EXPORT — oylik (har produkt ALOHIDA raster)
# ==============================================================

def _export_monthly(scene_images, roi, year, month, mode,
                   folder, scale, crs, tile_label='',
                   save_et=True, save_biomass=True,
                   save_etref=True, save_tact=True, save_eact=True):
    """
    Oylik rasterlar — har produkt ALOHIDA TIF.
    True/False bilan tanlash mumkin.
    """
    from . import monthly_analytics
    tasks = []

    prefix = f'_{tile_label}' if tile_label else ''
    month_str = f'{year}-{month:02d}'

    print(f"  Oylik hisoblash {month_str}...")

    if mode == 'pysebal':
        monthly = monthly_analytics.compute_all_monthly(
            scene_images, roi, year, month)
    else:
        monthly_et = daily_et.compute_monthly_et(
            scene_images, roi, year, month)
        monthly = monthly_et

    # Har produkt alohida export
    products = []
    if save_et:
        products.append(('ET', 'ET_MONTHLY', 'mm/month'))
    if save_biomass and mode == 'pysebal':
        products.append(('Biomass', 'BIOMASS_MONTHLY', 'kg/ha/month'))
    if save_etref and mode == 'pysebal':
        products.append(('ETref', 'ETREF_MONTHLY', 'mm/month'))
    if save_tact and mode == 'pysebal':
        products.append(('Tact', 'TACT_MONTHLY', 'mm/month'))
    if save_eact and mode == 'pysebal':
        products.append(('Eact', 'EACT_MONTHLY', 'mm/month'))
        
    print(f"  📐 Export region: {roi.bounds().coordinates().getInfo()}")

    for prod_name, band_name, unit in products:
        try:
            prod_image = monthly.select(band_name)

            # name = f'SEBAL_monthly_{prod_name}_{month_str}{prefix}'
            # task = ee.batch.Export.image.toDrive(
            #     image=prod_image.toFloat(),
            #     description=name, folder=folder, fileNamePrefix=name,
            #     region=roi, scale=scale, crs=crs,
            #     maxPixels=1e13, fileFormat='GeoTIFF')
            # task.start()
            # tasks.append(task.id)

            # # Statistika
            # mean_val = (prod_image
            #     .reduceRegion(ee.Reducer.mean(), roi, 1000,
            #                   maxPixels=1e9, bestEffort=True)
            #     .get(band_name))
            # mean_val = ee.Number(mean_val).getInfo()
            # print(f"  ✅ {prod_name}: {mean_val:.1f} {unit}")
            
                        # AVVAL statistika (GEE cache)
            mean_val = (prod_image
                .reduceRegion(ee.Reducer.mean(), roi, 1000,
                              maxPixels=1e9, bestEffort=True)
                .get(band_name))
            mean_val = ee.Number(mean_val).getInfo()
            print(f"  📊 {prod_name}: {mean_val:.1f} {unit}")

            # KEYIN export (cache dan tezroq)
            name = f'SEBAL_2026_{prod_name}_{month_str}{prefix}'
            task = ee.batch.Export.image.toDrive(
                image=prod_image.toFloat(),
                description=name, folder=folder, fileNamePrefix=name,
                region=roi, scale=scale, crs=crs,
                maxPixels=1e13, fileFormat='GeoTIFF')
            task.start()
            tasks.append(task.id)
            print(f"  ✅ {prod_name} export boshlandi")

        except Exception as e:
            print(f"  ⚠️ {prod_name}: {e}")

    return tasks


# ==============================================================
# MAIN RUN
# ==============================================================

def run(roi_type='gaul', date_start=None, date_end=None,
        mode='maqola', satellite='BOTH', cloud_max=20, validate=False,

        # Export sozlamalari
        export_daily=True,
        export_monthly=True,

        # Oylik produktlar (True/False)
        save_et=True,
        save_biomass=True,
        save_etref=True,
        save_tact=True,
        save_eact=True,

        # Tile sozlamalari
        tiles=None,          # [(156,32), (156,33)] yoki None=auto
        process_by_tile=False, # True=har tile alohida

        # Export sozlamalari
        folder='SEBAL_Output',
        scale=30,
        crs='EPSG:4326',

        **roi_kwargs):
    """
    SEBAL-GEE v4 production pipeline.

    Tile parametrlari:
      tiles=None, process_by_tile=False → ROI bo'yicha ishlash (kichik hududlar)
      tiles=None, process_by_tile=True  → avtomatik tile aniqlash
      tiles=[(156,32),(156,33)], process_by_tile=True → faqat shu tilelar
    """
    roi = cfg.build_roi(roi_type, **roi_kwargs)

    print(f"\n{'='*60}")
    print(f"  SEBAL-GEE v4 | Mode: {mode}")
    print(f"  ROI: {roi_type} | {date_start} → {date_end}")
    print(f"  Tile mode: {process_by_tile}")
    print(f"{'='*60}")

    all_tasks = []

    # ---- TILE-BASED PROCESSING ----
    if process_by_tile:
        if tiles is None:
            print("\n  WRS tiles aniqlanmoqda...")
            tiles = detect_wrs_tiles(roi, date_start, date_end,
                                     satellite, cloud_max)

        print(f"  Topilgan tiles: {tiles}")

        for path, row in tiles:
            tile_label = f'P{path}_R{row}'
            print(f"\n{'='*60}")
            print(f"  TILE: {tile_label}")
            print(f"{'='*60}")

            # Tile geometriyasi ROI bilan kesishish
            try:
                tile_geom = get_tile_geometry(path, row)
                tile_roi = roi.intersection(tile_geom)
            except:
                # WRS dataset topilmasa, ROI ni ishlatish
                tile_roi = roi

            scenes, info = process_tile(
                tile_roi, date_start, date_end, mode,
                satellite, cloud_max, tile_label)

            if not scenes:
                continue

            if export_daily:
                tasks = _export_daily(scenes, info, tile_roi, mode,
                                        folder, scale, crs, tile_label)
                all_tasks.extend(tasks)

            if export_monthly:
                from datetime import datetime
                start_dt = datetime.strptime(date_start, '%Y-%m-%d')
                tasks = _export_monthly(
                    scenes, tile_roi, start_dt.year, start_dt.month,
                    mode, folder, scale, crs, tile_label,
                    save_et, save_biomass, save_etref, save_tact, save_eact)
                all_tasks.extend(tasks)

    # ---- ROI-BASED PROCESSING (kichik hududlar) ----
    else:
        scenes, info = process_tile(
            roi, date_start, date_end, mode,
            satellite, cloud_max)

        if scenes:
            if export_daily:
                tasks = _export_daily(scenes, info, roi, mode,
                                        folder, scale, crs)
                all_tasks.extend(tasks)

            if export_monthly:
                from datetime import datetime
                start_dt = datetime.strptime(date_start, '%Y-%m-%d')
                tasks = _export_monthly(
                    scenes, roi, start_dt.year, start_dt.month,
                    mode, folder, scale, crs, '',
                    save_et, save_biomass, save_etref, save_tact, save_eact)
                all_tasks.extend(tasks)
                
    if validate and scenes:
            print("\n  Validation: SEBAL vs OpenET (oylik)...")
            try:
                from . import validation
                from . import monthly_analytics
                from datetime import datetime
                start_dt = datetime.strptime(date_start, '%Y-%m-%d')
                
                # Oylik ET hisoblash
                monthly = monthly_analytics.compute_all_monthly(
                    scenes, roi, start_dt.year, start_dt.month)
                
                # OpenET oylik olish (mm/month)
                openet = validation.get_openet_monthly(
                    roi, start_dt.year, start_dt.month)
                
                # Sampling
                combined = (monthly.select('ET_MONTHLY').rename('ET_SEBAL')
                        .addBands(openet))
                points = ee.FeatureCollection.randomPoints(roi, 2000, seed=42)
                sampled = combined.sampleRegions(
                    collection=points, scale=30, geometries=True)
                sampled = sampled.filter(ee.Filter.notNull(['ET_SEBAL']))
                
                n = sampled.size().getInfo()
                print(f"  Valid nuqtalar: {n}")
                
                print(f"\n  {'Model':<12} {'R²':>6} {'RMSE':>8} {'MBE':>8} {'SEBAL':>8} {'OpenET':>8}")
                print(f"  {'-'*56}")
                
                for band in openet.bandNames().getInfo():
                    name = band.replace('ET_', '')
                    try:
                        st = validation.compute_statistics(sampled, 'ET_SEBAL', band)
                        si = {k: v.getInfo() if hasattr(v, 'getInfo') else v
                            for k, v in st.items()}
                        print(f"  {name:<12} {si['r2']:>6.3f} {si['rmse']:>8.1f} "
                            f"{si['mbe']:>8.1f} {si['mean_sebal']:>8.1f} "
                            f"{si['mean_openet']:>8.1f}")
                    except Exception as e:
                        print(f"  {name:<12} ❌ {e}")
            except Exception as e:
                print(f"  ⚠️ Validation: {e}")
    

    # ---- XULOSA ----
    print(f"\n{'='*60}")
    print(f"  ✅ Tayyor! {len(all_tasks)} ta export task")
    print(f"  📁 Drive → {folder}/")
    print(f"  🔗 https://code.earthengine.google.com/tasks")
    print(f"{'='*60}")

    return {'tasks': all_tasks}

