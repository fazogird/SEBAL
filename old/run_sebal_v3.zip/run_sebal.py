"""
SEBAL-GEE v4 — Run Script
===========================
python run_sebal.py
"""

import ee
ee.Initialize(project="ee-chexovant11")

from sebal_gee_v4 import main

# ==============================================================
# QASHQADARYO — 2026 Mart
# ==============================================================

# result = main.run(
#     # ROI
#     roi_type='gaul',
#     name='Kashkadarya',
#     level=1,

#     # Sana
#     date_start='2026-03-01',
#     date_end='2026-03-31',

#     # Mode
#     mode='pysebal',        # 'maqola' yoki 'pysebal'
#     satellite='BOTH',
#     cloud_max=20,

#     # ---- TILE SOZLAMALARI ----
#     process_by_tile=True,                   # True = har tile alohida
#     tiles=[(156, 32), (156, 33)],           # qo'lda tanlash
#     # tiles=None,                           # None = avtomatik aniqlash

#     # ---- KUNLIK ----
#     export_daily=True,      # har sahna multi-band TIF

#     # ---- OYLIK (har biri alohida TIF) ----
#     export_monthly=True,
#     save_et=True,           # ET mm/month
#     save_biomass=True,      # Biomass kg/ha/month
#     save_etref=True,        # ETref mm/month
#     save_tact=True,         # Transpiratsiya mm/month
#     save_eact=True,         # Evaporatsiya mm/month

#     # ---- EXPORT ----
#     folder='SEBAL_Kashkadarya_2026',
#     scale=30,
#     crs='EPSG:32642',
# )


## ==============================================================
# IDAHO — VALIDATSIYA
# ==============================================================

# main.run(
#     roi_type='rectangle',
#     bounds=[-114.24, 43.03, -114.14, 43.13],
#     date_start='2024-07-01', date_end='2024-07-31',
#     mode='pysebal',
#     export_daily=True, export_monthly=True,
#     save_et=True, save_biomass=True,
#     save_etref=True, save_tact=True, save_eact=True,
#     validate=True,
#     folder='SEBAL_Idaho_Validation', crs='EPSG:32611',
# )


# ==============================================================
# QASHQADARYO — 2026 Mart
# ==============================================================
main.run(
    roi_type='gaul', name='Kashkadarya', level=1,
    date_start='2026-03-01', date_end='2026-03-31',
    mode='pysebal',
    satellite='BOTH', cloud_max=30,

    process_by_tile=True,
    tiles=[(155, 33), (156, 33)],

    export_daily=True, export_monthly=True,
    save_et=True, save_biomass=True,
    save_etref=True, save_tact=True, save_eact=True,

    validate=False,     # O'zbekiston — OpenET ishlamaydi
    folder='SEBAL_testtststs_2026-03',
    scale=30, crs='EPSG:32642',
)

# ==============================================================
# QASHQADARYO — 2026 Aprel
# ==============================================================
# main.run(
#     roi_type='gaul', name='Kashkadarya', level=1,
#     date_start='2026-04-01', date_end='2026-04-30',
#     mode='pysebal',
#     satellite='BOTH', cloud_max=30,

#     process_by_tile=True,
#     tiles=[(155, 33), (156, 33)],

#     export_daily=True, export_monthly=True,
#     save_et=True, save_biomass=True,
#     save_etref=True, save_tact=True, save_eact=True,

#     validate=False,
#     folder='SEBAL_Qash_2026-04',
#     scale=30, crs='EPSG:32642',
# )